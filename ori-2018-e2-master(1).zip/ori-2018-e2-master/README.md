# ori-2018-e2
Materijali za predmet Osnovi računarske inteligencije, školska 2017/2018
