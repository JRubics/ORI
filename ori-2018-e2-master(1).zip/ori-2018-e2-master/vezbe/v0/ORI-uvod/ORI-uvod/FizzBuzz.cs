﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ORI_uvod
{
    public class FizzBuzz
    {
        public static string GetFizzBuzz()
        {
            string fbString = "";
            // TODO 4: -Implementirati FizzBuzz algoritam
            return fbString;
        }
    }
}
