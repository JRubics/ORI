﻿
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
 
namespace ORI_uvod
{
    public static class MinMaxArraySwap
    {
        public static void MinMaxSwap(int[] input)
        {
            //TODO 5: Implementirati funkciju koja menja mesta MAX i MIN elementu u nizu
        }
    }
}

