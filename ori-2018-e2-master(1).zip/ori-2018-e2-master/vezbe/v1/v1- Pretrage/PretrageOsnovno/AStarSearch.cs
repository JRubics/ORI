﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PretrageOsnovno
{
    class AStarSearch
    {
        // TODO 7: implementirati algoritam za pretragu A*
        public State Search(string startNodeName, string endNodeName)
        {
            return null;
        }

    }
}
