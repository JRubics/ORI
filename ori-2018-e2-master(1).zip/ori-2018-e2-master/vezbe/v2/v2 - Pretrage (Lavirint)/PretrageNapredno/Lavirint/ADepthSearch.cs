﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Lavirint
{
    class ADepthSearch
    {
        //TODO 5: Implementirati klasu koja kombinuje algoritme Prvi u dubinu i A*
    }
}
