﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrgovackiPutnik
{
    public class Grad
    {
        public double x;
        public double y;

        public Grad(double aX, double aY) {
            x = aX;
            y = aY;
        }

    }
}
